~/ui/./start.sh
