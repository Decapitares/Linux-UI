Jde o jednoduchý script který funguje jako UI pro linux servery založené na Debian
UI je udělané pomocí Dialog boxu který je dostupný ve většině distribucí

spouštěcí script je ./start.sh

Složka UI musí být umístěna v domovské složce uživatele
Soubor ui.sh musí být umístěna v domovské složce uživatele