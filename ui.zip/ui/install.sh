get_info1() {
    echo "---------------------------------------------------- \n"
    echo "Zde naleznete info jak plne zprovoznit tento program \n"
    echo "---------------------------------------------------- \n"
    echo " \n"
    echo "1) Slozka program musi byt umisten ve slozce dokumenty (/home/username/Documents/a zde program) \n"
    echo " \n"
    echo "2) Ve slozce program je umistena spousteci ikona kterou zkopirujte do /home/Deca/.local/share/applications (tim se prida do appmenu ale pro funkcnost to neni podminka) \n"
    echo " \n"
    echo "A to je vse :)"
    echo " \n"
    echo "Tento program je pouze experimentalni a je vytvoren pouze za ucelem sebevzdelani \n"
}

brb=$(get_info1)
dialog --title "Install Info" --msgbox "$brb" 18 60

clear

~/Documents/program/./start.sh
