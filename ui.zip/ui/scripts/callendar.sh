#!/bin/bash 
function DialogGen 
{ 
dialog --calendar "calendar" 5 50 12 02 2022 
}
DialogGen 
clear
./ui.sh