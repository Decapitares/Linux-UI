echo "Vracím se na seznam scriptů"
sleep 0.3
clear
~/Documents/program/./start.sh