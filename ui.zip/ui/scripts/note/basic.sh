#!/bin/bash

# Funkce pro zobrazení dialogového okna pro výběr souboru
function note() {
    local filename=$(dialog --title "Vyber .txt soubor" --fselect "$HOME/Documents/program/scripts/note/" 14 70 2>&1 >/dev/tty)

    # Pokud uživatel nevybere žádný soubor nebo zavře okno, skript se ukončí
    if [[ -z "$filename" ]]; then
        echo "Nebyl vybrán žádný soubor."
        exit 1
    fi

    # Spustíme editaci vybraného souboru
    edit_file "$filename"
}

# Funkce pro editaci .txt souboru
function edit_file() {
    local file="$1"
    echo "Editace souboru: $file"

    # Zde můžete použít libovolný textový editor, například nano nebo vim
    # V tomto příkladu použijeme nano
    nano "$file"
}

# Spustíme funkci pro výběr souboru
note

~/Documents/program/./start.sh