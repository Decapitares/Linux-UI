zenity --info "Toto je obsah dialogov�ho okna."
