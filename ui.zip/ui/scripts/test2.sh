#!/bin/bash 

CURRENT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
#Hlavní menu
function menu() {
    cmd=(dialog --clear --backtitle "SIDEREUM | SCRIPT MENU" --title "HLAVNI MENU" --menu "Vyber si jednu z možností" 20 40 11)
    options=(1 "SSH"
             2 "Ping"
             3 "Callendar"
             4 "Test Script"
             5 "Note (WIP)"
             6 "Blbosti"
             7 "System Info"
             8 "reload")
    choices=$("${cmd[@]}" "${options[@]}" 2>&1 >/dev/tty)

    for choice in $choices
    do
        case $choice in
            1)
                ssh
                ;;
            2)
                ping
                ;;
            3)
                "$CURRENT_DIR/scripts/./callendar.sh"
                ;;
            4)
                "$CURRENT_DIR/scripts/./test.sh"
                ;;
            5)
                note
                ;;
            6)
                blbosti
                ;;
            7)
                "$CURRENT_DIR/scripts/./system-info.sh"
                ;;
            8)
                menu
                ;;
        esac
    done
}

#ssh menu
function ssh() {
    cmd=(dialog --clear --backtitle "SIDEREUM | SSH MENU" --title "SSH" --menu "Vyber si jednu z možností" 20 40 11)

    options=(1 "Prox Linux"
             2 "Proxmox"
             3 "Win Linux"
             4 "BACK")
    choices=$("${cmd[@]}" "${options[@]}" 2>&1 >/dev/tty)

    for choice in $choices
    do
        case $choice in
            1)
                clear ; "$CURRENT_DIR/scripts/ssh/./prox.sh"
                ;;
            2)
                clear ; "$CURRENT_DIR/scripts/ssh/./proxmox.sh"
                ;;
            3)
                clear ; "$CURRENT_DIR/scripts/ssh/./win.sh"
                ;;
            4)
                menu
                ;;
        esac
    done
}

#ping menu
function ping() {
    cmd=(dialog --clear --backtitle "SIDEREUM | PING MENU" --title "PING" --menu "Vyber si jednu z možností" 20 40 11)

    options=(1 "Prox Linux"
             2 "Proxmox"
             3 "Router"
             4 "Win Linux"
             5 "Universal (manuální zadání IP"
             6 "BACK")
    choices=$("${cmd[@]}" "${options[@]}" 2>&1 >/dev/tty)

    for choice in $choices
    do
        case $choice in
            1)
                "$CURRENT_DIR/ping/./prox.sh"
                ;;
            2)
                "$CURRENT_DIR/ping/./proxmox.sh"
                ;;
            3)
                "$CURRENT_DIR/ping/./router.sh"
                ;;
            4)  
                "$CURRENT_DIR/ping/./win.sh"
                ;;
            5)
                "$CURRENT_DIR/ping/./universal.sh"
                ;;
            6)
                menu
                ;;
        esac
    done
}

#note menu
function note() {
    cmd=(dialog --clear --backtitle "SIDEREUM | NOTE MENU" --title "NOTE (WIP)" --menu "Vyber si jednu z možností" 20 40 11)

    options=(1 "Note"
             2 "Back")
    choices=$("${cmd[@]}" "${options[@]}" 2>&1 >/dev/tty)

    for choice in $choices
    do
        case $choice in
            1)
                "$CURRENT_DIR/scripts/note/./basic.sh"
                ;;
            2)
                menu
                ;;
        esac
    done
}

#blbosti menu
function blbosti() {
    cmd=(dialog --clear --backtitle "SIDEREUM | BLBOSTI MENU" --title "BLBOSTI" --menu "Vyber si jednu z možností" 20 40 11)

    options=(1 "Mrk"
             2 "Nyan"
             3 "BACK")
    choices=$("${cmd[@]}" "${options[@]}" 2>&1 >/dev/tty)

    for choice in $choices
    do
        case $choice in
            1)
                "$CURRENT_DIR/scripts/blbosti/./mrk.sh"
                ;;
            2)
                "$CURRENT_DIR/scripts/blbosti/./nyan.sh"
                ;;
            3)
                menu
                ;;
        esac
    done
}

menu
clear